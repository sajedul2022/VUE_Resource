@extends('layouts.guest')

@section('content')
  <front-template></front-template>
@endsection
