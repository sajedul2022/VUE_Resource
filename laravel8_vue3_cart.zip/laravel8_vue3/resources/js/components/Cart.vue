<script setup>
  import axios from 'axios';
</script>

<template >
    <div>
        {{ cartItems }} 
    </div>
</template>

<script>

export default {
    data() {
        return {
            cartItems: '',
        }
    },

    methods: {
        getCartItems(){
            axios.get("api/cart").then((response) =>{
                // alert(response.data);
                this.cartItems = response.data;
            })
        }
    },
    mounted() {
        this.getCartItems();
    },
}
</script>

<style lang="">
    
</style>