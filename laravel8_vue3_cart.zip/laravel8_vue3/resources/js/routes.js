// pages
import Home from "./pages/Home.vue";
import Shop from "./pages/Shop.vue";

// Routing
import { createRouter, createWebHistory } from "vue-router";

const routes = [
    { path: "/", component: Home },
    { path: "/shop", component: Shop },
];

const router = createRouter({
history: createWebHistory(),
routes, // short for `routes: routes`
linkActiveClass: "active"
});

export default router;